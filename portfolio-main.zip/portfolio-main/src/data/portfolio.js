export const portfolioData=[{
    imgSrc:"dummy1.jpg",
    title:"Full Stack Prokect built using MERN",
    desc:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi odio magni perferendis autem libero perspiciatis dolorem molestias? Minima deserunt, laboriosam perferendis vel temporibus reiciendis eum sint exercitationem architecto, explicabo nihil.",
    url:"https://cashkaro.com/"

},{
    imgSrc:"dummy1.jpg",
    title:"Full Stack Prokect built using MERN",
    desc:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi odio magni perferendis autem libero perspiciatis dolorem molestias? Minima deserunt, laboriosam perferendis vel temporibus reiciendis eum sint exercitationem architecto, explicabo nihil.",
    url:"https://cashkaro.com/"

},{
    imgSrc:"dummy1.jpg",
    title:"Full Stack Prokect built using MERN",
    desc:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi odio magni perferendis autem libero perspiciatis dolorem molestias? Minima deserunt, laboriosam perferendis vel temporibus reiciendis eum sint exercitationem architecto, explicabo nihil.",
    url:"https://cashkaro.com/"

},{
    imgSrc:"dummy1.jpg",
    title:"Full Stack Prokect built using MERN",
    desc:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi odio magni perferendis autem libero perspiciatis dolorem molestias? Minima deserunt, laboriosam perferendis vel temporibus reiciendis eum sint exercitationem architecto, explicabo nihil.",
    url:"https://cashkaro.com/"

},]