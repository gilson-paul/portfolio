export const my={
    name:"Apoorva Karn",
    brandName:"Apoorv Karn",
    email:"aaron.finance.mj@gmail.com",
    phoneNo:"+91 89018 65173",
    whatsappNo:"+918901865173",
    address:"New Delhi, India",
    location:"https://maps.app.goo.gl/LJJHQATQF7F1MaAu5",


}