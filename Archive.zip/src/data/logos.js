export const logos = [
    'express.jpg',
    'mongodb.jpg',
    'nextjs.jpg',
    'nodejs.jpg',
    'reactjs.jpg',
    'tailwind.jpg',
    'redis.jpg'
  ];